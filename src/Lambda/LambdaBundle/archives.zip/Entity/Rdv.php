<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Rdv
 *
 * @ORM\Table(name="rdv")
 * @ORM\Entity
 */
class Rdv
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEmprunt", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idemprunt;

    /**
     * @var integer
     *
     * @ORM\Column(name="idAdresseUser", type="integer", nullable=false)
     */
    private $idadresseuser;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateRDV", type="datetime", nullable=false)
     */
    private $daterdv;



    /**
     * Get idemprunt
     *
     * @return integer
     */
    public function getIdemprunt()
    {
        return $this->idemprunt;
    }

    /**
     * Set idadresseuser
     *
     * @param integer $idadresseuser
     *
     * @return Rdv
     */
    public function setIdadresseuser($idadresseuser)
    {
        $this->idadresseuser = $idadresseuser;

        return $this;
    }

    /**
     * Get idadresseuser
     *
     * @return integer
     */
    public function getIdadresseuser()
    {
        return $this->idadresseuser;
    }

    /**
     * Set daterdv
     *
     * @param \DateTime $daterdv
     *
     * @return Rdv
     */
    public function setDaterdv($daterdv)
    {
        $this->daterdv = $daterdv;

        return $this;
    }

    /**
     * Get daterdv
     *
     * @return \DateTime
     */
    public function getDaterdv()
    {
        return $this->daterdv;
    }
}
