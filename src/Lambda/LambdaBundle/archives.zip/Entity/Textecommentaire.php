<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Textecommentaire
 *
 * @ORM\Table(name="textecommentaire")
 * @ORM\Entity
 */
class Textecommentaire
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idCommentaire", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idcommentaire;

    /**
     * @var string
     *
     * @ORM\Column(name="texteCommentaire", type="string", length=400)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $textecommentaire;



    /**
     * Set idcommentaire
     *
     * @param integer $idcommentaire
     *
     * @return Textecommentaire
     */
    public function setIdcommentaire($idcommentaire)
    {
        $this->idcommentaire = $idcommentaire;

        return $this;
    }

    /**
     * Get idcommentaire
     *
     * @return integer
     */
    public function getIdcommentaire()
    {
        return $this->idcommentaire;
    }

    /**
     * Set textecommentaire
     *
     * @param string $textecommentaire
     *
     * @return Textecommentaire
     */
    public function setTextecommentaire($textecommentaire)
    {
        $this->textecommentaire = $textecommentaire;

        return $this;
    }

    /**
     * Get textecommentaire
     *
     * @return string
     */
    public function getTextecommentaire()
    {
        return $this->textecommentaire;
    }
}
