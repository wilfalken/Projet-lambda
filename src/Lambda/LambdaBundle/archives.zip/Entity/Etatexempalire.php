<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Etatexempalire
 *
 * @ORM\Table(name="etatexempalire")
 * @ORM\Entity
 */
class Etatexempalire
{
    /**
     * @var string
     *
     * @ORM\Column(name="etat", type="string", length=400)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $etat;

    /**
     * @var integer
     *
     * @ORM\Column(name="idExemplaire", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idexemplaire;



    /**
     * Set etat
     *
     * @param string $etat
     *
     * @return Etatexempalire
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return string
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set idexemplaire
     *
     * @param integer $idexemplaire
     *
     * @return Etatexempalire
     */
    public function setIdexemplaire($idexemplaire)
    {
        $this->idexemplaire = $idexemplaire;

        return $this;
    }

    /**
     * Get idexemplaire
     *
     * @return integer
     */
    public function getIdexemplaire()
    {
        return $this->idexemplaire;
    }
}
