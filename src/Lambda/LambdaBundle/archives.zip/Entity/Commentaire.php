<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Commentaire
 *
 * @ORM\Table(name="commentaire")
 * @ORM\Entity
 */
class Commentaire
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idCommentaire", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idcommentaire;

    /**
     * @var integer
     *
     * @ORM\Column(name="idUser", type="integer", nullable=false)
     */
    private $iduser;

    /**
     * @var integer
     *
     * @ORM\Column(name="idItem", type="integer", nullable=false)
     */
    private $iditem;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateAjout", type="datetime", nullable=false)
     */
    private $dateajout = 'CURRENT_TIMESTAMP';

    /**
     * @var integer
     *
     * @ORM\Column(name="idCommente", type="integer", nullable=false)
     */
    private $idcommente;

    /**
     * @var integer
     *
     * @ORM\Column(name="idType", type="integer", nullable=false)
     */
    private $idtype;



    /**
     * Get idcommentaire
     *
     * @return integer
     */
    public function getIdcommentaire()
    {
        return $this->idcommentaire;
    }

    /**
     * Set iduser
     *
     * @param integer $iduser
     *
     * @return Commentaire
     */
    public function setIduser($iduser)
    {
        $this->iduser = $iduser;

        return $this;
    }

    /**
     * Get iduser
     *
     * @return integer
     */
    public function getIduser()
    {
        return $this->iduser;
    }

    /**
     * Set iditem
     *
     * @param integer $iditem
     *
     * @return Commentaire
     */
    public function setIditem($iditem)
    {
        $this->iditem = $iditem;

        return $this;
    }

    /**
     * Get iditem
     *
     * @return integer
     */
    public function getIditem()
    {
        return $this->iditem;
    }

    /**
     * Set dateajout
     *
     * @param \DateTime $dateajout
     *
     * @return Commentaire
     */
    public function setDateajout($dateajout)
    {
        $this->dateajout = $dateajout;

        return $this;
    }

    /**
     * Get dateajout
     *
     * @return \DateTime
     */
    public function getDateajout()
    {
        return $this->dateajout;
    }

    /**
     * Set idcommente
     *
     * @param integer $idcommente
     *
     * @return Commentaire
     */
    public function setIdcommente($idcommente)
    {
        $this->idcommente = $idcommente;

        return $this;
    }

    /**
     * Get idcommente
     *
     * @return integer
     */
    public function getIdcommente()
    {
        return $this->idcommente;
    }

    /**
     * Set idtype
     *
     * @param integer $idtype
     *
     * @return Commentaire
     */
    public function setIdtype($idtype)
    {
        $this->idtype = $idtype;

        return $this;
    }

    /**
     * Get idtype
     *
     * @return integer
     */
    public function getIdtype()
    {
        return $this->idtype;
    }
}
