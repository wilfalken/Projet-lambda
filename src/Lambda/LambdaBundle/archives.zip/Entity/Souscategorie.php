<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Souscategorie
 *
 * @ORM\Table(name="souscategorie")
 * @ORM\Entity
 */
class Souscategorie
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idSousCategorie", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idsouscategorie;

    /**
     * @var string
     *
     * @ORM\Column(name="nomSousCategorie", type="string", length=50, nullable=false)
     */
    private $nomsouscategorie;



    /**
     * Get idsouscategorie
     *
     * @return integer
     */
    public function getIdsouscategorie()
    {
        return $this->idsouscategorie;
    }

    /**
     * Set nomsouscategorie
     *
     * @param string $nomsouscategorie
     *
     * @return Souscategorie
     */
    public function setNomsouscategorie($nomsouscategorie)
    {
        $this->nomsouscategorie = $nomsouscategorie;

        return $this;
    }

    /**
     * Get nomsouscategorie
     *
     * @return string
     */
    public function getNomsouscategorie()
    {
        return $this->nomsouscategorie;
    }
}
