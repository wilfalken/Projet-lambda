<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Liensouscategorie
 *
 * @ORM\Table(name="liensouscategorie")
 * @ORM\Entity
 */
class Liensouscategorie
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idCategorie", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idcategorie;

    /**
     * @var integer
     *
     * @ORM\Column(name="idSousCategorie", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idsouscategorie;



    /**
     * Set idcategorie
     *
     * @param integer $idcategorie
     *
     * @return Liensouscategorie
     */
    public function setIdcategorie($idcategorie)
    {
        $this->idcategorie = $idcategorie;

        return $this;
    }

    /**
     * Get idcategorie
     *
     * @return integer
     */
    public function getIdcategorie()
    {
        return $this->idcategorie;
    }

    /**
     * Set idsouscategorie
     *
     * @param integer $idsouscategorie
     *
     * @return Liensouscategorie
     */
    public function setIdsouscategorie($idsouscategorie)
    {
        $this->idsouscategorie = $idsouscategorie;

        return $this;
    }

    /**
     * Get idsouscategorie
     *
     * @return integer
     */
    public function getIdsouscategorie()
    {
        return $this->idsouscategorie;
    }
}
