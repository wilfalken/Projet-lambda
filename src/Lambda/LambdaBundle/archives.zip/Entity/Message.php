<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Message
 *
 * @ORM\Table(name="message")
 * @ORM\Entity
 */
class Message
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idMessage", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idmessage;

    /**
     * @var integer
     *
     * @ORM\Column(name="idUserExp", type="integer", nullable=false)
     */
    private $iduserexp;

    /**
     * @var integer
     *
     * @ORM\Column(name="idUserDest", type="integer", nullable=false)
     */
    private $iduserdest;

    /**
     * @var string
     *
     * @ORM\Column(name="sujet", type="string", length=50, nullable=false)
     */
    private $sujet;

    /**
     * @var string
     *
     * @ORM\Column(name="corps", type="text", length=65535, nullable=false)
     */
    private $corps;

    /**
     * @var integer
     *
     * @ORM\Column(name="typeMessage", type="integer", nullable=false)
     */
    private $typemessage;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateEnvoi", type="datetime", nullable=false)
     */
    private $dateenvoi = 'CURRENT_TIMESTAMP';



    /**
     * Get idmessage
     *
     * @return integer
     */
    public function getIdmessage()
    {
        return $this->idmessage;
    }

    /**
     * Set iduserexp
     *
     * @param integer $iduserexp
     *
     * @return Message
     */
    public function setIduserexp($iduserexp)
    {
        $this->iduserexp = $iduserexp;

        return $this;
    }

    /**
     * Get iduserexp
     *
     * @return integer
     */
    public function getIduserexp()
    {
        return $this->iduserexp;
    }

    /**
     * Set iduserdest
     *
     * @param integer $iduserdest
     *
     * @return Message
     */
    public function setIduserdest($iduserdest)
    {
        $this->iduserdest = $iduserdest;

        return $this;
    }

    /**
     * Get iduserdest
     *
     * @return integer
     */
    public function getIduserdest()
    {
        return $this->iduserdest;
    }

    /**
     * Set sujet
     *
     * @param string $sujet
     *
     * @return Message
     */
    public function setSujet($sujet)
    {
        $this->sujet = $sujet;

        return $this;
    }

    /**
     * Get sujet
     *
     * @return string
     */
    public function getSujet()
    {
        return $this->sujet;
    }

    /**
     * Set corps
     *
     * @param string $corps
     *
     * @return Message
     */
    public function setCorps($corps)
    {
        $this->corps = $corps;

        return $this;
    }

    /**
     * Get corps
     *
     * @return string
     */
    public function getCorps()
    {
        return $this->corps;
    }

    /**
     * Set typemessage
     *
     * @param integer $typemessage
     *
     * @return Message
     */
    public function setTypemessage($typemessage)
    {
        $this->typemessage = $typemessage;

        return $this;
    }

    /**
     * Get typemessage
     *
     * @return integer
     */
    public function getTypemessage()
    {
        return $this->typemessage;
    }

    /**
     * Set dateenvoi
     *
     * @param \DateTime $dateenvoi
     *
     * @return Message
     */
    public function setDateenvoi($dateenvoi)
    {
        $this->dateenvoi = $dateenvoi;

        return $this;
    }

    /**
     * Get dateenvoi
     *
     * @return \DateTime
     */
    public function getDateenvoi()
    {
        return $this->dateenvoi;
    }
}
