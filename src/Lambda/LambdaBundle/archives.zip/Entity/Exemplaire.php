<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Exemplaire
 *
 * @ORM\Table(name="exemplaire")
 * @ORM\Entity
 */
class Exemplaire
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idUser", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $iduser;

    /**
     * @var integer
     *
     * @ORM\Column(name="idItem", type="integer", nullable=false)
     */
    private $iditem;

    /**
     * @var string
     *
     * @ORM\Column(name="etat", type="string", length=50, nullable=false)
     */
    private $etat;

    /**
     * @var string
     *
     * @ORM\Column(name="photoExemplaire", type="string", length=150, nullable=true)
     */
    private $photoexemplaire;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateAjout", type="datetime", nullable=false)
     */
    private $dateajout = 'CURRENT_TIMESTAMP';



    /**
     * Get iduser
     *
     * @return integer
     */
    public function getIduser()
    {
        return $this->iduser;
    }

    /**
     * Set iditem
     *
     * @param integer $iditem
     *
     * @return Exemplaire
     */
    public function setIditem($iditem)
    {
        $this->iditem = $iditem;

        return $this;
    }

    /**
     * Get iditem
     *
     * @return integer
     */
    public function getIditem()
    {
        return $this->iditem;
    }

    /**
     * Set etat
     *
     * @param string $etat
     *
     * @return Exemplaire
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return string
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set photoexemplaire
     *
     * @param string $photoexemplaire
     *
     * @return Exemplaire
     */
    public function setPhotoexemplaire($photoexemplaire)
    {
        $this->photoexemplaire = $photoexemplaire;

        return $this;
    }

    /**
     * Get photoexemplaire
     *
     * @return string
     */
    public function getPhotoexemplaire()
    {
        return $this->photoexemplaire;
    }

    /**
     * Set dateajout
     *
     * @param \DateTime $dateajout
     *
     * @return Exemplaire
     */
    public function setDateajout($dateajout)
    {
        $this->dateajout = $dateajout;

        return $this;
    }

    /**
     * Get dateajout
     *
     * @return \DateTime
     */
    public function getDateajout()
    {
        return $this->dateajout;
    }
}
