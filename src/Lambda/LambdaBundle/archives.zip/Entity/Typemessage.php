<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Typemessage
 *
 * @ORM\Table(name="typemessage")
 * @ORM\Entity
 */
class Typemessage
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idMessage", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idmessage;

    /**
     * @var string
     *
     * @ORM\Column(name="typeMessage", type="string", length=50)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $typemessage;



    /**
     * Set idmessage
     *
     * @param integer $idmessage
     *
     * @return Typemessage
     */
    public function setIdmessage($idmessage)
    {
        $this->idmessage = $idmessage;

        return $this;
    }

    /**
     * Get idmessage
     *
     * @return integer
     */
    public function getIdmessage()
    {
        return $this->idmessage;
    }

    /**
     * Set typemessage
     *
     * @param string $typemessage
     *
     * @return Typemessage
     */
    public function setTypemessage($typemessage)
    {
        $this->typemessage = $typemessage;

        return $this;
    }

    /**
     * Get typemessage
     *
     * @return string
     */
    public function getTypemessage()
    {
        return $this->typemessage;
    }
}
