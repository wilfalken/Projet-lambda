<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Groupe
 *
 * @ORM\Table(name="groupe")
 * @ORM\Entity
 */
class Groupe
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idGroupe", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idgroupe;

    /**
     * @var string
     *
     * @ORM\Column(name="nomGroupe", type="string", length=50, nullable=false)
     */
    private $nomgroupe;



    /**
     * Get idgroupe
     *
     * @return integer
     */
    public function getIdgroupe()
    {
        return $this->idgroupe;
    }

    /**
     * Set nomgroupe
     *
     * @param string $nomgroupe
     *
     * @return Groupe
     */
    public function setNomgroupe($nomgroupe)
    {
        $this->nomgroupe = $nomgroupe;

        return $this;
    }

    /**
     * Get nomgroupe
     *
     * @return string
     */
    public function getNomgroupe()
    {
        return $this->nomgroupe;
    }
}
