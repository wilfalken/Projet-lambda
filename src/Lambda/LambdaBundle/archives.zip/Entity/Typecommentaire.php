<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Typecommentaire
 *
 * @ORM\Table(name="typecommentaire")
 * @ORM\Entity
 */
class Typecommentaire
{
    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=400)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $description;

    /**
     * @var integer
     *
     * @ORM\Column(name="idCommentaire", type="integer", nullable=false)
     */
    private $idcommentaire;



    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set idcommentaire
     *
     * @param integer $idcommentaire
     *
     * @return Typecommentaire
     */
    public function setIdcommentaire($idcommentaire)
    {
        $this->idcommentaire = $idcommentaire;

        return $this;
    }

    /**
     * Get idcommentaire
     *
     * @return integer
     */
    public function getIdcommentaire()
    {
        return $this->idcommentaire;
    }
}
