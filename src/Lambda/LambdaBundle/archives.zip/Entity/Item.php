<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Item
 *
 * @ORM\Table(name="item")
 * @ORM\Entity
 */
class Item
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idItem", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $iditem;

    /**
     * @var string
     *
     * @ORM\Column(name="nomItem", type="string", length=50, nullable=false)
     */
    private $nomitem;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=150, nullable=false)
     */
    private $description;

    /**
     * @var integer
     *
     * @ORM\Column(name="note", type="integer", nullable=true)
     */
    private $note;

    /**
     * @var string
     *
     * @ORM\Column(name="photoItem", type="string", length=100, nullable=false)
     */
    private $photoitem;

    /**
     * @var boolean
     *
     * @ORM\Column(name="isValide", type="boolean", nullable=false)
     */
    private $isvalide = '1';



    /**
     * Get iditem
     *
     * @return integer
     */
    public function getIditem()
    {
        return $this->iditem;
    }

    /**
     * Set nomitem
     *
     * @param string $nomitem
     *
     * @return Item
     */
    public function setNomitem($nomitem)
    {
        $this->nomitem = $nomitem;

        return $this;
    }

    /**
     * Get nomitem
     *
     * @return string
     */
    public function getNomitem()
    {
        return $this->nomitem;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Item
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set note
     *
     * @param integer $note
     *
     * @return Item
     */
    public function setNote($note)
    {
        $this->note = $note;

        return $this;
    }

    /**
     * Get note
     *
     * @return integer
     */
    public function getNote()
    {
        return $this->note;
    }

    /**
     * Set photoitem
     *
     * @param string $photoitem
     *
     * @return Item
     */
    public function setPhotoitem($photoitem)
    {
        $this->photoitem = $photoitem;

        return $this;
    }

    /**
     * Get photoitem
     *
     * @return string
     */
    public function getPhotoitem()
    {
        return $this->photoitem;
    }

    /**
     * Set isvalide
     *
     * @param boolean $isvalide
     *
     * @return Item
     */
    public function setIsvalide($isvalide)
    {
        $this->isvalide = $isvalide;

        return $this;
    }

    /**
     * Get isvalide
     *
     * @return boolean
     */
    public function getIsvalide()
    {
        return $this->isvalide;
    }
}
