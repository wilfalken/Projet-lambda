<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Lienemprunt
 *
 * @ORM\Table(name="lienemprunt")
 * @ORM\Entity
 */
class Lienemprunt
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEmprunt", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idemprunt;

    /**
     * @var integer
     *
     * @ORM\Column(name="idEmprunteur", type="integer", nullable=false)
     */
    private $idemprunteur;

    /**
     * @var integer
     *
     * @ORM\Column(name="idProprietaire", type="integer", nullable=false)
     */
    private $idproprietaire;



    /**
     * Get idemprunt
     *
     * @return integer
     */
    public function getIdemprunt()
    {
        return $this->idemprunt;
    }

    /**
     * Set idemprunteur
     *
     * @param integer $idemprunteur
     *
     * @return Lienemprunt
     */
    public function setIdemprunteur($idemprunteur)
    {
        $this->idemprunteur = $idemprunteur;

        return $this;
    }

    /**
     * Get idemprunteur
     *
     * @return integer
     */
    public function getIdemprunteur()
    {
        return $this->idemprunteur;
    }

    /**
     * Set idproprietaire
     *
     * @param integer $idproprietaire
     *
     * @return Lienemprunt
     */
    public function setIdproprietaire($idproprietaire)
    {
        $this->idproprietaire = $idproprietaire;

        return $this;
    }

    /**
     * Get idproprietaire
     *
     * @return integer
     */
    public function getIdproprietaire()
    {
        return $this->idproprietaire;
    }
}
