<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Usergenre
 *
 * @ORM\Table(name="usergenre")
 * @ORM\Entity
 */
class Usergenre
{
    /**
     * @var integer
     *
     * @ORM\Column(name="iduser", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $iduser;

    /**
     * @var integer
     *
     * @ORM\Column(name="idgenre", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idgenre;



    /**
     * Set iduser
     *
     * @param integer $iduser
     *
     * @return Usergenre
     */
    public function setIduser($iduser)
    {
        $this->iduser = $iduser;

        return $this;
    }

    /**
     * Get iduser
     *
     * @return integer
     */
    public function getIduser()
    {
        return $this->iduser;
    }

    /**
     * Set idgenre
     *
     * @param integer $idgenre
     *
     * @return Usergenre
     */
    public function setIdgenre($idgenre)
    {
        $this->idgenre = $idgenre;

        return $this;
    }

    /**
     * Get idgenre
     *
     * @return integer
     */
    public function getIdgenre()
    {
        return $this->idgenre;
    }
}
