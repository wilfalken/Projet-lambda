<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Emprunt
 *
 * @ORM\Table(name="emprunt")
 * @ORM\Entity
 */
class Emprunt
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idEmprunt", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idemprunt;

    /**
     * @var integer
     *
     * @ORM\Column(name="idExemplaire", type="integer", nullable=false)
     */
    private $idexemplaire;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateEmprunt", type="datetime", nullable=false)
     */
    private $dateemprunt = 'CURRENT_TIMESTAMP';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateRendu", type="datetime", nullable=false)
     */
    private $daterendu;



    /**
     * Get idemprunt
     *
     * @return integer
     */
    public function getIdemprunt()
    {
        return $this->idemprunt;
    }

    /**
     * Set idexemplaire
     *
     * @param integer $idexemplaire
     *
     * @return Emprunt
     */
    public function setIdexemplaire($idexemplaire)
    {
        $this->idexemplaire = $idexemplaire;

        return $this;
    }

    /**
     * Get idexemplaire
     *
     * @return integer
     */
    public function getIdexemplaire()
    {
        return $this->idexemplaire;
    }

    /**
     * Set dateemprunt
     *
     * @param \DateTime $dateemprunt
     *
     * @return Emprunt
     */
    public function setDateemprunt($dateemprunt)
    {
        $this->dateemprunt = $dateemprunt;

        return $this;
    }

    /**
     * Get dateemprunt
     *
     * @return \DateTime
     */
    public function getDateemprunt()
    {
        return $this->dateemprunt;
    }

    /**
     * Set daterendu
     *
     * @param \DateTime $daterendu
     *
     * @return Emprunt
     */
    public function setDaterendu($daterendu)
    {
        $this->daterendu = $daterendu;

        return $this;
    }

    /**
     * Get daterendu
     *
     * @return \DateTime
     */
    public function getDaterendu()
    {
        return $this->daterendu;
    }
}
