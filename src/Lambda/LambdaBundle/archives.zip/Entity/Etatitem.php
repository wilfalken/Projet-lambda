<?php

namespace Lambda\LambdaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Etatitem
 *
 * @ORM\Table(name="etatitem")
 * @ORM\Entity
 */
class Etatitem
{
    /**
     * @var integer
     *
     * @ORM\Column(name="idItem", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $iditem;

    /**
     * @var string
     *
     * @ORM\Column(name="etatInitial", type="string", length=400)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $etatinitial;



    /**
     * Set iditem
     *
     * @param integer $iditem
     *
     * @return Etatitem
     */
    public function setIditem($iditem)
    {
        $this->iditem = $iditem;

        return $this;
    }

    /**
     * Get iditem
     *
     * @return integer
     */
    public function getIditem()
    {
        return $this->iditem;
    }

    /**
     * Set etatinitial
     *
     * @param string $etatinitial
     *
     * @return Etatitem
     */
    public function setEtatinitial($etatinitial)
    {
        $this->etatinitial = $etatinitial;

        return $this;
    }

    /**
     * Get etatinitial
     *
     * @return string
     */
    public function getEtatinitial()
    {
        return $this->etatinitial;
    }
}
